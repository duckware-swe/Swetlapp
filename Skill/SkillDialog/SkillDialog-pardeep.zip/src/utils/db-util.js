

var exports = module.exports = {};



exports.getWF = getWF;
/*
["spike",[{"name":"Top Gear","time":"10:15"},
        {"name":"Top Gear","time":"11:30"},
        {"name":"Top Gear","time":"12:35"},
        {"name":"Top Gear","time":"13:35"},
        {"name":"Top Gear","time":"14:45"},
        {"name":"Top Gear","time":"15:55"}
        ]
]
["cielo",[{"name":"Love it or list it - Prendere o lasciare Vancouver","time":"10:55"},
        {"name":"Fratelli in affari","time":"11:55"},
        {"name":"Fratelli in affari","time":"12:55"},
        {"name":"Innamorarsi a Manhattan","time":"13:55"},
        {"name":"La banda dei pensionati","time":"15:40"}
        ]
]*/